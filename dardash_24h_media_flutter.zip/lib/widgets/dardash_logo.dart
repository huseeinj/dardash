
import 'package:flutter/material.dart';

class DardashLogo extends StatelessWidget {
  final double size;
  const DardashLogo({super.key, this.size = 76});

  @override
  Widget build(BuildContext context) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(size * .28),
      gradient: const LinearGradient(
        colors: [Color(0xFF8667FF), Color(0xFF4C2BD4)],
        begin: Alignment.topLeft, end: Alignment.bottomRight,
      ),
      boxShadow: const [BoxShadow(color: Color(0x664F35D5), blurRadius: 22)],
    ),
    child: Icon(Icons.forum_rounded, size: size*.56, color: Colors.white),
  );
}
